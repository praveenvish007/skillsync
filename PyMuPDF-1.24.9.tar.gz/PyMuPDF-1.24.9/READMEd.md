# PyMuPDFd

This wheel contains [MuPDF](https://mupdf.readthedocs.io/) build-time files
that were used to build [PyMuPDF](https://pymupdf.readthedocs.io/).
