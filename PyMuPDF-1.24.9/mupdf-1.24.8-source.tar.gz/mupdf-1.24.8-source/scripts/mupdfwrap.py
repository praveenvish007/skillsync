#! /usr/bin/env python3

import wrap.__main__

if __name__ == '__main__':
    wrap.__main__.main()
